=====<About>=====
For Mugen 1.0+ ONLY!
A Patch to Add Artificial Intelligence into DivineWolf's Juli, it's A.I. is scaled
by Difficulty in the options menu, it's 90% Cammy' Ai from P.O.T.S when she is using palette 7 to 12.
Pretty lazy right? Yeah... whatever, they are pretty much the same character so i don't care.
I touched her coding for A.I usage too btw, but i think she should be close to the original.
All right... have fun playing with cammy.

=====<Ai Patch Usage Instructions>=====
If you have the original character already then just replace your DivineJuli folder in chars
with the one that came with this readme, it should be enough, if not download Divinewolf's
original character first.